
ArrayList<Person> people = new ArrayList<>(); // ArrayList vom Typ   <-- Person ist ein komplexer Datentyp
ArrayList<String> ArticleNames = new ArrayList<>(); // ArrayList vom Typ String <-- String ist ein primitiver Datentyp

// Daten in der Datei records.txt
// John Doe, 23
// Monika Lewinski, 25
try (Scanner scanner = new Scanner(Paths.get("records.txt"))) {

    while (scanner.hasNextLine()) {
        String line = scanner.nextLine();

        String[] parts = line.split(","); // String[] = ein array vom Typ String
        String name = parts[0];
        int age = Integer.valueOf(parts[1]);
        var p = new Person(name, age); // erzeuge das Objekt p vom Typ Person

        people.add(p); // füge ein Objket vom Typ Person der ArrayList hinzu
    } // lese alle Zeilen der Datei und schreibe diese in die ArrayList people

    // Typ  Objekt  --> Der Typ ist die Klasse Person und das Objekt p0 ist eine Instanz diese Klasse (John 23 Jahr alt)
    Person p0 = people.get(0); // lade das erste Element aus der ArrayList people
    if(p0.name == "John") {
        // mach etwas mit dem Objekt  p0
    };
}

System.out.println("Total amount of people read: " + people.size());


public Article