using System;
using System.Collections.Generic;
using Xunit;
using Shoplzk.Core;

namespace Shoplzk.Tests
{

    #region What tests should be run?
    // if inStock == 5  -->  reorder. 
    // if quantity == 3 -->  discount of 3% on PriceNet
    #endregion


    public class Invoice_BusinessLogic
    {
        private readonly Dictionary<int, Article>  _articles;
        // private readonly IEnumerable<CartItem>  _cartItems;
        // private readonly Invoice _invoice;


        // Constructor  
        public Invoice_BusinessLogic()
        {
            _articles = SeedData.GetArticles();
            // _cartItems = SeedData.GetCartItems(); 

            // _invoice = new Invoice(1, _cartItems);
        }

        // Facts are tests which are always true. They test invariant conditions.
        // Theories are tests which are only true for a particular set of data.
        [Fact]
        public void Discount_ThreePercent_on_NetPrice_from_3_Articles()
        {
            decimal priceNet = 2.00m;
            decimal discountFactor = 0.5m;
            int qty = 3;
            int id =1;
            var article = new Article( id, name: "foo", priceNet: priceNet);
            var cartItem = new CartItem(article, qty); // WarenkorbPosition
            var result = new InvoiceItem(1, cartItem).getTotal(netTotal: true); // Rechnungsposition
            // Expected: 3 * 2 * 0.5 = 3
            // Actual: ?
            
            Assert.Equal(priceNet * qty * discountFactor, result);
        }

        [Fact]
        public void Discount_ThreePercent_on_GrossPrice_from_3_Articles()
        {
            decimal priceNet = 2.00m;
            decimal discountFactor = 0.5m;
            int qty = 3;
            var article = new Article(1, "foo", priceNet);
            var cartItem = new CartItem(article, qty);
            var result = new InvoiceItem(1, cartItem).getTotal();
            // Expected: (3 * 2 * 1.19) * 0.5 = 3.?
            // Actual: 6,925800
            
            Assert.Equal(priceNet * qty * discountFactor, result);
        }


    } // end of class

    #region Links

        // Infos to tests https://docs.microsoft.com/en-us/dotnet/core/testing/
        // xunit https://xunit.net/docs/getting-started/netcore/cmdline
        // xunit https://docs.microsoft.com/en-us/dotnet/core/testing/unit-testing-with-dotnet-test
        // Sample Project
        // https://github.com/dotnet/samples/blob/master/core/getting-started/unit-testing-using-dotnet-test/PrimeService.Tests/PrimeService_IsPrimeShould.cs
        // 
        // Infos on attributtes
        // Attributes provide a powerful method of associating metadata, or declarative information, with code 
        // https://docs.microsoft.com/de-de/dotnet/csharp/programming-guide/concepts/attributes/
    #endregion
}
