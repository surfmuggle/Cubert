﻿using System;

namespace Shoplzk.Core
{
    public class InventoryItem
    {
        public int Id {get; private set; }

        public int ArticleId {get; private set; }
        public int Qty {get; private set; }
        public Article Article {get; private set; }
        // private int qty = 0;

        public InventoryItem(int articleId)
        {
            this.ArticleId= articleId;   
        }
        public InventoryItem(Article article, int  qty)
        {
            this.Article= article;
            this.Qty = qty;    
        }

        public int checkStock()
        {
            return 20;
        }
    }// class
} // namespace
