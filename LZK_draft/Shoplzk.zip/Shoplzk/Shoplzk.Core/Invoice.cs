using System.Collections.Generic;
using System.Linq;

namespace Shoplzk.Core
{
    public class Invoice
    {
        public int Id {get; private set; }
        public int UserId {get; private set; }

        public List<CartItem> CartItems {get; private set; }
        private int qty = 0;

        public Invoice(int userId, IEnumerable<CartItem> cartItems)
        {
            this.UserId = userId;
            this.CartItems = cartItems.ToList<CartItem>();  //   explicit cast / conversion 
        }

        public decimal getInvoiceTotal()
        {
            var invoiceItems = new List<InvoiceItem>();
            foreach(CartItem cartItem in this.CartItems)
            {
                invoiceItems.Add(new InvoiceItem(this.Id, cartItem));
            }
            decimal total = invoiceItems.Sum(invoiceItem => invoiceItem.getTotal(netTotal:true)); // named parameters use a :
            return total;
        }


    }// class
} // namespace
