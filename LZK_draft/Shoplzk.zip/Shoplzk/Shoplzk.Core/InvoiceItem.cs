namespace Shoplzk.Core
{
    public class InvoiceItem
    {
        public int InvoiceId {get; private set; }
        public int Id {get; private set; }

        private decimal discountThreeOrMore = 0.5m;


        public CartItem CartItem {get; private set; }
        private int qty = 0;

        public InvoiceItem(int invoiceId, CartItem cartItem)
        {
            this.InvoiceId = invoiceId;
            this.CartItem = cartItem;    
        }

        public decimal getTotal(bool netTotal = false)
        {
            if(netTotal)
            {
               return this.getInvoiceItemNetTotal();
            } 
            return this.getInvoiceItemGrossTotal();
        }

        private decimal getInvoiceItemGrossTotal()
        {
            if(this.CartItem.Qty >= 3)
            {
                return CartItem.Qty * CartItem.Article.PriceGross * discountThreeOrMore;
            }
            return CartItem.Qty * CartItem.Article.PriceGross;
        }

        private decimal getInvoiceItemNetTotal()
        {
            if(this.CartItem.Qty >= 3)
            {
                return CartItem.Qty * CartItem.Article.PriceNet * discountThreeOrMore;
            }
            return CartItem.Qty * CartItem.Article.PriceNet;
        }


    }// class
} // namespace
