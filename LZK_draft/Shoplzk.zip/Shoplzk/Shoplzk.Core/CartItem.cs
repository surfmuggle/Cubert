using System;

namespace Shoplzk.Core
{

public class CartItem
{

    // Auto-implemented properties for trivial get and set
    // https://docs.microsoft.com/de-de/dotnet/csharp/programming-guide/classes-and-structs/auto-implemented-properties
    // https://docs.microsoft.com/de-de/dotnet/csharp/programming-guide/classes-and-structs/properties mit Beispiel für Berechnung
    public int Id{get; private set; }
    public int ArticleId{get; private set; }
    public int Qty { get; set; }

    public Article Article {get; set; }

    public CartItem()
    {
        
    }


    public CartItem(Article article, int qty)
    {
        this.Article = article;
        this.Qty = qty;
    }

    public CartItem(int id, Article article, int qty)
    {
        this.Id = id;
        this.Qty = qty;
        this.Article = article;
    }

    // Expression Body Definition siehe https://docs.microsoft.com/de-de/dotnet/csharp/language-reference/operators/lambda-operator  
    public decimal Total => this.Qty * this.Article.PriceGross;

    public decimal getTotal()
    {
        return this.Qty * this.Article.PriceGross;
    } 
}

}
