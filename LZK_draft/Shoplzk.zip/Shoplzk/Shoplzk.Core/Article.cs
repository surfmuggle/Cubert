﻿using System;

namespace Shoplzk.Core
{


public class Article
{
    private decimal steuersatz = 0.19m;

    public int Id {get; private set; }
    public string Name {get; private set; }

    // do not use double see https://stackoverflow.com/questions/693372/what-is-the-best-data-type-to-use-for-money-in-c 
    public decimal PriceGross {get; private set; }
    public decimal PriceNet {get; private set; }

    public Article(int id, string name, decimal priceNet)
    {
        this.Id = id;
        this.Name = name;
        this.PriceNet = priceNet;
        this.PriceGross = priceNet * (1 + steuersatz);
    }

}
}
