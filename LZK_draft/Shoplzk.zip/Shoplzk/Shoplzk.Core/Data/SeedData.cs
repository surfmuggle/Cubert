// https://github.com/dotnet-architecture/eShopOnWeb

using System;
using System.Collections.Generic;

namespace Shoplzk.Core
{

    // Guidelines for Collections
    // https://docs.microsoft.com/en-us/dotnet/standard/design-guidelines/guidelines-for-collections?redirectedfrom=MSDN
    // DO use Collection<T> or a subclass for properties or return values
    // representing read/write collections.
    public class SeedData
    {
        

        // New Silvans Turbo (DVD)	7,50€	20
        // Afrim und Bashkim (DVD)	6,00€	20
        // Daniel allein zu Haus (DVD)	4,50	20
        // Call of Duty – Phillips War (PC)	30,00€	20
        // Call of Duty – Phillips War (PS4)	40,00€	20
        // Cybernico 2077  (PC)		40,00€	20
        // Cybernico 2077 (PS4)	50,00€	20
        public static IEnumerable<Article> GetArticlesOld()
        {
            var articles = new List<Article>();
            articles.Add(new Article(10, "New Silvans Turbo (DVD)", 7.50m));
            articles.Add(new Article(11, "Afrim und Bashkim (DVD)", 6.00m));
            articles.Add(new Article(12, "Daniel allein zu Haus (DVD)", 4.50m));
            articles.Add(new Article(13, "Call of Duty – Phillips War (PC)", 30.00m));
            articles.Add(new Article(14, "Call of Duty – Phillips War (PS4)", 40.00m));
            articles.Add(new Article(15, "Cybernico 2077  (PC)", 40.00m));
            articles.Add(new Article(16, "Cybernico 2077 (PS4)", 50.00m));
            return articles;
        }

        public static Dictionary<int, Article> GetArticles()
        {
            var articles = new Dictionary<int, Article>();
            articles.Add(10, new Article(10, "New Silvans Turbo (DVD)", 7.50m));
            articles.Add(11, new Article(11, "Afrim und Bashkim (DVD)", 6.00m));
            articles.Add(12, new Article(12, "Daniel allein zu Haus (DVD)", 4.50m));
            articles.Add(13, new Article(13, "Call of Duty – Phillips War (PC)", 30.00m));
            articles.Add(14, new Article(14, "Call of Duty – Phillips War (PS4)", 40.00m));
            articles.Add(15, new Article(15, "Cybernico 2077  (PC)", 40.00m));
            articles.Add(16, new Article(16, "Cybernico 2077 (PS4)", 50.00m));
            return articles;
        }


        /// getInventory would be normaly stored inside a database
        public static IEnumerable<CartItem> GetCartItems(IEnumerable<Article> articles)
        {      
            var items = new List<CartItem>();
            int i = 1;
            foreach(Article article in articles)
            {
                items.Add(new CartItem(id: i, article: article, qty: 3));
                i++;
            }
            return items;
        }    



               /// getInventory would be normaly stored inside a database
        public static IEnumerable<InventoryItem> GetInventory(IList<Article> articles)
        {      
            var inventoryItemList = new List<InventoryItem>();
            foreach(Article article in articles)
            {
                inventoryItemList.Add(new InventoryItem(article: article, qty : 20));
            }
            return inventoryItemList;
        }

        #region DemoCode

            // instead of this 
            // var inventoryList = new List<Inventory>();
            // inventoryList.Add(new Inventory(10, 20))
            // below we use named arguments with :
            // Named Arguments: https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/named-and-optional-arguments#named-arguments
            // you could also use 
            // Collection initializers https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/classes-and-structs/object-and-collection-initializers#collection-initializers
            // var items = new List<CartItem>
            // {
            //     new CartItem(articleId : 10, qty:3),
            //     new CartItem(articleId : 11, qty:3),
            //     new CartItem(articleId : 16, qty:3)
            // };

        #endregion // DemoCode

        // Todo: Learn use of yield modified from https://jeremylindsayni.wordpress.com/2015/01/01/c-tip-try-to-return-ienumerable-instead-of-ilist-and-when-not-to/
        // better explanation https://www.kenneth-truyers.net/2016/05/12/yield-return-in-c/
        // private static IEnumerable<Article> ConvertCartItemsToArticleList(IEnumerable<CartItem> cartItems)
        // {
        //     foreach (var cartItem in cartItems)
        //     {
        //         yield return new Article { 
        //             Id = cartItem.ArticleId, 
        //             Name = cartItem.Article.Name 
        //         };
        //     }
        // }        
    }

}