﻿using System;
using System.Collections.Generic;
using System.Linq;
using Shoplzk.Core;

namespace Shoplzk.ConsoleApp
{

    // How to add projects, tests to a solution?
    // https://docs.microsoft.com/en-us/dotnet/core/testing/unit-testing-with-dotnet-test
    // https://stackoverflow.com/a/60464210/819887     
    class Program
    {


        // ab Lagerbestand 5 Stück -->  Nachbestellung. 
        // ab 3 Artikeln   Rabatt 3%, auf den gesamten Netto-Preis
        

        private const string messageEnterArticlenumberAndQty = "Please enter articleid and quantity in this format 'id=quantity'. Example 4 times 123 -> '123=4'.";
        private const string messageStop = "Entering 'stop' terminates the current action.";
        private const string invoiceHeader = "Invoice Header";

        static void Main(string[] args)
        {

            // Lade Artikel
            Dictionary<int, Article> articles = SeedData.GetArticles();
        
            bool continueShopping  = true;
            while(continueShopping)
            {            
                // zeige Artikel an
                listArticles(articles);

                // welche kommen in den Warenkorb 
                parseInputForCartItems(articles);

                // weiter einkaufen oder beenden
                continueShopping = keepShopping();
            } // run programm
        } // Main


        private static void listArticles(Dictionary<int, Article> articles)
        {
            foreach(Article a in articles.Values)
            {
                Console.WriteLine("{0}    {1}     {2} Euro", a.Id, a.Name, a.PriceGross);
            }
        }

        private static List<CartItem> parseInputForCartItems(Dictionary<int, Article> articles)
        {
            var cartItemList = new List<CartItem>();
            bool keepParsing = true;
            Console.WriteLine(messageEnterArticlenumberAndQty);
            Console.WriteLine(messageStop);
            while(keepParsing)
            {                

                string input = Console.ReadLine();
                
                int articleId, articleQty;
                bool inputIsValid = validateInput(input, out articleId, out articleQty);
                
                if(inputIsValid)
                {
                    // var article = articleList // .Find(a => a.Id == articleId);
                    Article article;
                    if (articles.TryGetValue(articleId, out article))
                    {

                        var inventoryItem = new InventoryItem(article.Id);
                        int inStock = inventoryItem.checkStock();
                        if(inStock >= articleQty)
                        {
                            var cartItem = new CartItem(article, articleQty);
                            cartItemList.Add(cartItem);
                            Console.WriteLine("hinzugefügt: {0}   {1}x", cartItem.Article.Name, cartItem.Qty);
                        } else {
                            Console.WriteLine("Es sind leider nur  {0} Stück im Lager", inStock); 
                        }
                    } 
                    else {
                         Console.WriteLine("Die articleId {0} kann nicht gefunden werden.", articleId);
                    }
                }
                else if(input =="stop"){
                    keepParsing = false;
                }else {
                    Console.WriteLine("Die Eingabe kann nicht verarbeitet werden. Bitte beachten Sie den folgenden Hinweis.");
                    Console.WriteLine(messageEnterArticlenumberAndQty);
                }
            }
            return cartItemList;
        }

        private static bool validateInput(string input, out int articleId, out int articleQty)
        {
            bool isValid = false;
            string[] idQty = input.Split("=");
            if(idQty.Length != 2)
            {
                // throw new ArgumentException("input must look like 123=4");
                Console.WriteLine("input must look like 123=4");
            } 
            else if (idQty.Length == 2 
                        && Int32.TryParse(idQty[0], out articleId) 
                        && Int32.TryParse(idQty[1], out articleQty)){
                isValid = true;
                return isValid;
            }
            articleId = 0;
            articleQty = 0;
            return isValid;
        }

        private static bool keepShopping()
        {
            // this can be improved - do you know how and why?
            Console.WriteLine("Möchten Sie weiter shoppen? Geben Sie Y oder N ein");
            string input = Console.ReadLine();
            if(input== "Y") 
            {
                return true;
            }
            return false;
        }
    }
}
